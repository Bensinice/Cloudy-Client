/* Cloudy – Erweiterungen der Oberfläche: Themes, Updater, Einführung, Ressourcen-Manager.
   Nutzt die Helfer aus index.html ($, $$, st, esc, go, play, openMod, chips, catName, version). */

// ---------- Themes ----------
const THEMES = [
  { id: 'light', name: 'Cloudy Blau', bg: ['#eaf5ff', '#a9d4ff'], c: '#4aa3ff' },
  { id: 'dark', name: 'Cloudy Nacht', bg: ['#11244a', '#0a1328'], c: '#4aa3ff' },
  { id: 'pink-light', name: 'Light Pink', bg: ['#fff3f8', '#ffbfdc'], c: '#ff5fa2' },
  { id: 'pink-dark', name: 'Dark Pink', bg: ['#2e0f21', '#1c0a14'], c: '#ff5fa2' },
  { id: 'purple-light', name: 'Light Purple', bg: ['#f5eeff', '#cdb0ff'], c: '#8b5cf6' },
  { id: 'purple-dark', name: 'Dark Purple', bg: ['#1e1040', '#120a24'], c: '#9d6bff' },
  { id: 'lavender', name: 'Lavender', bg: ['#f7f3ff', '#d6c8f3'], c: '#a58be0' },
  { id: 'midnight', name: 'Midnight Purple', bg: ['#120b26', '#07050f'], c: '#7c5cff' },
  { id: 'lunar', name: 'Lunar (Slate)', bg: ['#0d1422', '#070b14'], c: '#38bdf8' },
  { id: 'ember', name: 'Ember', bg: ['#42200f', '#150a07'], c: '#ff7a3c' },
  { id: 'forest', name: 'Forest', bg: ['#143823', '#07140d'], c: '#3fd08a' },
  { id: 'paper', name: 'Paper', bg: ['#fafaf7', '#e2e0d6'], c: '#2b2b2b' },
  { id: 'mono', name: 'Dark', bg: ['#232325', '#0b0b0c'], c: '#f2f2f2' },
  { id: 'glass', name: 'Glas (durchsichtig)', bg: ['#6fa8dc', '#1b3350'], c: '#8ccbff' },
  { id: 'system', name: 'System', bg: ['#eaf5ff', '#11244a'], c: '#4aa3ff' }
];
const PAIR = { light: 'dark', dark: 'light', 'pink-light': 'pink-dark', 'pink-dark': 'pink-light', 'purple-light': 'purple-dark', 'purple-dark': 'purple-light', lavender: 'midnight', midnight: 'lavender', lunar: 'paper', paper: 'mono', mono: 'paper', glass: 'light', ember: 'light', forest: 'light' };
const sysDark = matchMedia('(prefers-color-scheme: dark)');
function themeId() {
  const t = st.get('theme', 'light');
  if (t === 'system') return sysDark.matches ? 'dark' : 'light';
  return THEMES.some(x => x.id === t && x.id !== 'system') ? t : 'light';
}
function applyTheme() {
  const id = themeId(), root = document.documentElement;
  root.dataset.theme = id;
  const cs = getComputedStyle(root), dark = cs.getPropertyValue('--mode').trim() === 'dark';
  $('#themeBtn span').textContent = dark ? 'Heller Modus' : 'Dunkler Modus';
  $$('.th').forEach(b => b.classList.toggle('on', b.dataset.id === st.get('theme', 'light')));
  const th = THEMES.find(x => x.id === id) || THEMES[0];
  window.cloudy.themeColor({ bg: cs.getPropertyValue('--title-bg').trim(), fg: cs.getPropertyValue('--ink').trim(), id, sky: [th.bg[1], th.bg[0]], accent: th.c, dark }).catch(() => {});
}
$('#themeGrid').innerHTML = THEMES.map(t => `<button class="th" data-id="${t.id}"><i style="background:linear-gradient(135deg,${t.bg[0]},${t.bg[1]});--sw:${t.c}"></i>${t.name}</button>`).join('');
$$('.th').forEach(b => b.onclick = () => { st.set('theme', b.dataset.id); applyTheme(); });
$('#themeBtn').onclick = () => { st.set('theme', PAIR[themeId()] || 'light'); applyTheme(); };
sysDark.onchange = () => { if (st.get('theme', 'light') === 'system') applyTheme(); };
applyTheme();

// ---------- Fensterknöpfe (Windows) ----------
if (/Windows/i.test(navigator.userAgent)) document.documentElement.classList.add('win');
$('#wcMin').onclick = () => window.cloudy.winCtl('min'); $('#wcMax').onclick = () => window.cloudy.winCtl('max'); $('#wcX').onclick = () => window.cloudy.winCtl('close');

// ---------- Schnellzugriff ----------
$$('[data-go]').forEach(b => b.onclick = () => go(b.dataset.go));
$('#heroPlay').onclick = () => play();

// ---------- Updates ----------
let upd = null, updBusy = false;
const MB = n => (n / 1048576).toFixed(1);
const setUpd = t => { $('#updMsg').textContent = t; $('#updBS').textContent = t; };
const bars = (on, pct) => $$('.ubar').forEach(b => { b.classList.toggle('on', on); if (pct != null) b.firstElementChild.style.width = pct + '%'; });
async function repoName() { const i = await window.cloudy.appVersion(); return i.repo || st.get('repo', ''); }
async function checkUpd(manual) {
  const repo = await repoName();
  if (!repo) { if (manual) setUpd('Trage deine GitHub-Quelle ein (z. B. name/cloudy).'); return; }
  if (manual) { $('#upd').disabled = true; setUpd('Prüfe …'); }
  const r = await window.cloudy.checkUpdate(repo);
  $('#upd').disabled = false;
  if (!r.ok) { if (manual) setUpd(r.error); return; }
  upd = r;
  if (r.newer) {
    $('#updBT').textContent = `Cloudy ${r.latest} ist verfügbar`;
    setUpd(`Neue Version ${r.latest} (du hast ${r.current})${r.size ? ' · ' + MB(r.size) + ' MB' : ''}`);
    $('#updBanner').classList.add('on');
    $('#upd').textContent = r.canInstall ? 'Jetzt aktualisieren' : 'Download-Seite öffnen';
    $('#updNow').textContent = $('#updHome').textContent = $('#upd').textContent;
  } else { $('#updBanner').classList.remove('on'); $('#upd').textContent = 'Nach Updates suchen'; if (manual) setUpd(`Cloudy ${r.current} ist aktuell.`); }
}
async function runUpdate() {
  if (updBusy) return;
  updBusy = true; $('#upd').disabled = $('#updNow').disabled = $('#updHome').disabled = true; bars(true, 0); setUpd('Lade Update …');
  const r = await window.cloudy.updateInstall();
  if (!r.ok) { updBusy = false; $('#upd').disabled = $('#updNow').disabled = $('#updHome').disabled = false; bars(false); setUpd(r.error || 'Update fehlgeschlagen.'); }
}
$('#upd').onclick = () => upd && upd.newer ? runUpdate() : checkUpd(true);
$('#updNow').onclick = runUpdate;
$('#updHome').onclick = async () => { // Update-Knopf auf der Startseite
  if (upd && upd.newer) return runUpdate();
  const b = $('#updHome'); b.disabled = true; b.textContent = 'Prüfe …';
  await checkUpd(true);
  b.disabled = false;
  if (upd && upd.newer) return;
  b.textContent = 'Nach Updates suchen';
  $('#updBT').textContent = 'Update-Prüfung'; $('#updBS').textContent = $('#updMsg').textContent;
  $('#updNow').style.display = 'none'; $('#updBanner').classList.add('on');
  setTimeout(() => { $('#updBanner').classList.remove('on'); $('#updNow').style.display = ''; }, 6000);
};
$('#repo').value = st.get('repo', '');
$('#repo').onchange = e => st.set('repo', e.target.value.trim());
window.cloudy.on('update-progress', p => {
  if (p.phase === 'download') { bars(true, p.pct); setUpd(`Lade herunter … ${Math.round(p.pct)} % (${MB(p.got)} / ${MB(p.total)} MB)`); }
  else { bars(true, 100); setUpd('Installiere und starte Cloudy neu …'); }
});
window.cloudy.appVersion().then(i => {
  $('#updMsg').textContent = 'Cloudy ' + i.v;
  if (i.repo) $('#repoRow').style.display = 'none';
  $('#heroVer').textContent = 'Cloudy ' + i.v + (i.suffix ? ' ' + i.suffix : '');
  $('#updMsg').textContent = 'Cloudy ' + i.v + (i.suffix ? ' ' + i.suffix : '');
  window.cloudy.autoUpdGet().then(on => { // Beim Start prüfen; mit Auto-Accept gleich installieren, sonst nach 10 s nachfragen
    $('#autoUpd').checked = on;
    setTimeout(async () => { await checkUpd(false); if (upd && upd.newer && upd.mandatory) return forceUpd(); if (upd && upd.newer && upd.canInstall) offerUpdate('Cloudy ' + upd.latest, runUpdate); await checkUrlUpd(); }, 2500);
    setInterval(async () => { await checkUpd(false); if (upd && upd.newer && upd.mandatory) forceUpd(); else await checkUrlUpd(); }, 3 * 3600 * 1000);
  });
});
// Pflicht-Update: nach 24 Stunden wird eine neuere Version ohne Rückfrage installiert (Zurückgehen auf ältere Versionen gibt es nicht)
let forcing = false;
function forceUpd(url) {
  if (forcing || updBusy) return; forcing = true;
  const d = document.createElement('div'); d.style.cssText = 'position:fixed;inset:0;z-index:99998;display:grid;place-items:center;background:rgba(8,16,34,.55);backdrop-filter:blur(8px)';
  d.innerHTML = '<div class="glass set" style="padding:22px 26px;max-width:420px;text-align:center"><h3 style="margin:0 0 6px">Pflicht-Update</h3><p class="muted" id="fuMsg">Eine neue Cloudy-Version ist seit über einem Tag verfügbar und wird jetzt installiert …</p><div class="ubar on"><i style="width:0"></i></div></div>';
  document.body.appendChild(d);
  (async () => {
    let r; if (url) { r = await window.cloudy.updateFromUrl(url); if (!r.ok) r.error = r.msg; } else r = await window.cloudy.updateInstall();
    if (r && !r.ok) { $('#fuMsg').textContent = (r.error || 'Update fehlgeschlagen.') + ' Cloudy versucht es später erneut.'; setTimeout(() => { d.remove(); forcing = false; }, 6000); }
  })();
}
async function checkUrlUpd() { const u = st.get('updUrl', ''); if (!u) return; const r = await window.cloudy.updateCheckUrl(u); if (r && r.ok && r.newer) { if (r.mandatory) forceUpd(u); else offerUpdate('Cloudy ' + r.latest, () => window.cloudy.updateFromUrl(u)); } }
// Rückfrage: 10 Sekunden warten, dann fragen. „Immer automatisch“ schaltet Auto-Accept ein (in den Einstellungen wieder aus).
let askBusy = null;
function askUpdate(label) { // Apple-artige Abfrage: erst 10 s Hinweis, dann „Update verfügbar“ mit Jetzt / Später
  if (askBusy) return askBusy;
  askBusy = new Promise(res => {
    const en = (document.documentElement.lang || 'de') === 'en', tx = (d, e) => en ? e : d;
    const toast = document.createElement('div'); toast.className = 'updt'; document.body.appendChild(toast);
    let n = 10; const paint = () => { toast.textContent = tx(`${label} gefunden – Rückfrage in ${n} s`, `${label} found – asking in ${n} s`); }; paint();
    const tick = setInterval(() => {
      n--; if (n > 0) return paint(); clearInterval(tick); toast.remove();
      const box = document.createElement('div'); box.className = 'updq'; box.setAttribute('role', 'alertdialog');
      box.innerHTML = `<div class="updsheet"><div class="uph"><b>${tx('Update verfügbar', 'Update Available')}</b><p>${esc(label)} ${tx('kann jetzt installiert werden. Cloudy startet danach neu.', 'can be installed now. Cloudy restarts afterwards.')}</p></div><div class="upr"><button data-a="n">${tx('Später', 'Later')}</button><button data-a="y" class="p">${tx('Jetzt aktualisieren', 'Update Now')}</button></div><div class="upr one"><button data-a="auto">${tx('Immer automatisch', 'Always Automatic')}</button></div></div>`;
      document.body.appendChild(box);
      box.querySelectorAll('[data-a]').forEach(b => b.onclick = async () => { const a = b.dataset.a; if (a === 'auto') { await window.cloudy.autoUpdSet(true); $('#autoUpd').checked = true; } box.classList.add('out'); setTimeout(() => box.remove(), 180); askBusy = null; res(a !== 'n'); });
    }, 1000);
  });
  return askBusy;
}
// Auto-Accept: sofort. Sonst fragen; bei „Später“ nach 10 Minuten noch einmal.
async function offerUpdate(label, go) { if (await window.cloudy.autoUpdGet()) return go(); if (await askUpdate(label)) go(); else setTimeout(() => offerUpdate(label, go), 600000); }
window.cloudy.on('updateFound', d => offerUpdate(d && d.name ? d.name.replace(/\.zip$/i, '') : 'Update', () => window.cloudy.localUpdateRun({})));
$('#autoUpd').onchange = e => window.cloudy.autoUpdSet(e.target.checked);

// ---------- Einführung (nur beim ersten Start) ----------
const ICO = {
  cloud: '<path d="M17.5 19a4.5 4.5 0 1 0-1.7-8.7A6 6 0 1 0 5 14.5 4 4 0 0 0 6.5 19z"/>',
  play: '<circle cx="12" cy="12" r="9"/><path d="M10 8.5l6 3.5-6 3.5z"/>',
  mods: '<path d="M12 2l9 5v10l-9 5-9-5V7zM12 12l9-5M12 12v10M12 12L3 7"/>',
  pack: '<rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/>',
  style: '<circle cx="12" cy="12" r="9"/><circle cx="8.5" cy="10" r="1.2"/><circle cx="12" cy="7.5" r="1.2"/><circle cx="15.5" cy="10" r="1.2"/><path d="M12 21c-1.5 0-2-1.2-1.4-2.3.6-1 .2-2.2-1-2.2H8"/>'
};
const OB = [
  { i: ICO.cloud, t: 'Willkommen bei Cloudy', p: 'Dein Minecraft-Launcher in Wolkenoptik. In einer Minute zeigen wir dir, wie alles funktioniert.' },
  { i: ICO.play, t: 'Version wählen und spielen', p: 'Unter „Versionen“ suchst du dir eine Minecraft-Version aus. Der große Spielen-Knopf startet das Spiel. Java und alle Dateien lädt Cloudy automatisch.' },
  { i: ICO.mods, t: 'Mods mit Fabric', p: 'Im Tab „Mods“ findest du Mods von Modrinth. Fabric richtet Cloudy selbst ein. In der „Bibliothek“ schaltest du Mods ein oder aus, suchst und löschst sie.' },
  { i: ICO.pack, t: 'Ressourcenpakete und Shader', p: 'Im Tab „Ressourcen“ verwaltest du Ressourcenpakete und Shader. Für Shader installiert Cloudy bei Bedarf Fabric und Iris dazu.' },
  { i: ICO.style, t: 'Dein Stil, dein Konto', p: 'In den Einstellungen wählst du eines von vielen Farbthemen, meldest dich mit Microsoft an und hältst Cloudy mit einem Klick aktuell.' }
];
let obStep = 0;
function obDone() { st.set('onboarded', true); $('#onb').classList.remove('on'); }
function obDraw() {
  const s = OB[obStep], last = obStep === OB.length - 1;
  $('#obBox').innerHTML = `<div class="slide" key="${obStep}"><div class="art"><svg viewBox="0 0 24 24">${s.i}</svg></div><h2>${s.t}</h2><p>${s.p}</p></div>
    <div class="dots">${OB.map((_, i) => `<i class="${i === obStep ? 'on' : ''}"></i>`).join('')}</div>
    <div class="go"><button class="btn ghost" id="obSkip">Überspringen</button><button class="btn" id="obNext">${last ? 'Los geht’s' : 'Weiter'}</button></div>`;
  $('#obSkip').onclick = obDone;
  $('#obNext').onclick = () => { if (last) obDone(); else { obStep++; obDraw(); } };
}
function showOnb() { obStep = 0; obDraw(); $('#onb').classList.add('on'); }
$('#onbAgain').onclick = showOnb;


// ---------- Ressourcen-Manager (Ressourcenpakete + Shader) ----------
let ptype = 'resourcepack', pver = '', pcat = 'all', pq = '', pdata = [];
async function loadPacks() {
  const lib = await window.cloudy.libList();
  const ids = [...new Set([version, ...lib.map(x => x.id)].filter(Boolean))];
  if (!pver || !ids.includes(pver)) pver = version || ids[0] || '';
  $('#pver').innerHTML = ids.map(i => `<option value="${esc(i)}" ${i === pver ? 'selected' : ''}>${esc(iname(i))}</option>`).join(''); paintPCats();
  $('#phint').textContent = ptype === 'shader' ? 'Shader laufen mit Fabric und Iris. Cloudy installiert beide beim Herunterladen eines Shaders automatisch.' : 'Ausgeschaltete Pakete bleiben gespeichert, erscheinen aber nicht im Spiel.';
  await refreshPacks();
  searchPacks();
}
async function refreshPacks() {
  if (!pver) { $('#plist').innerHTML = '<p class="muted">Wähle zuerst eine Version.</p>'; return; }
  paintPacks(await window.cloudy.packList(pver, ptype));
  const v = pver, t = ptype;
  window.cloudy.packEnrich(v, t).then(m => { if (v === pver && t === ptype) paintPacks(m); }).catch(() => {});
}
function paintPacks(m) {
  pdata = m;
  const cats = [...new Set(m.flatMap(x => x.cats || []))].sort();
  if (!['all', 'on', 'off', ...cats].includes(pcat)) pcat = 'all';
  $('#pcats').innerHTML = chips([['all', 'Alle (' + m.length + ')'], ['on', 'Aktiv'], ['off', 'Ausgeschaltet'], ...cats.map(c => [c, catName(c)])], pcat);
  $$('#pcats [data-c]').forEach(b => b.onclick = () => { pcat = b.dataset.c; paintPacks(pdata); });
  const q = pq.trim().toLowerCase();
  const list = m.filter(x => (pcat === 'all' || (pcat === 'on' ? x.enabled : pcat === 'off' ? !x.enabled : (x.cats || []).includes(pcat))) && (!q || (x.name + ' ' + x.file + ' ' + (x.desc || '') + ' ' + (x.cats || []).map(c => c + ' ' + catName(c)).join(' ')).toLowerCase().includes(q)));
  $('#plist').innerHTML = list.map(x => {
    const ic = x.icon ? `<img class="mi" src="${esc(x.icon)}" alt="">` : `<span class="ph">${esc((x.name[0] || '?').toUpperCase())}</span>`;
    return `<div class="glass srv">${ic}<div class="tx"><b ${x.project ? `class="clk" data-o="${esc(x.project)}"` : ''}>${esc(x.name)}</b>${x.desc ? `<small class="d">${esc(x.desc)}</small>` : ''}<small>${esc(x.file)}${x.folder ? ' · Ordner' : ''}${x.enabled ? '' : ' · ausgeschaltet'}</small></div><label class="sw" title="An/Aus"><input type="checkbox" data-t="${esc(x.file)}" ${x.enabled ? 'checked' : ''}><i></i></label><button class="btn ghost" data-rm="${esc(x.file)}">Löschen</button></div>`;
  }).join('') || `<p class="muted" style="margin-top:12px">${m.length ? 'Nichts gefunden.' : ptype === 'shader' ? 'Noch keine Shader installiert.' : 'Noch keine Ressourcenpakete installiert.'}</p>`;
  $$('#plist [data-t]').forEach(c => c.onchange = async () => { await window.cloudy.packToggle(pver, ptype, c.dataset.t); refreshPacks(); });
  $$('#plist [data-rm]').forEach(b => b.onclick = async () => { if (!confirm('Dieses Paket löschen?')) return; await window.cloudy.packRemove(pver, ptype, b.dataset.rm); refreshPacks(); });
  $$('#plist [data-o]').forEach(n => n.onclick = () => openMod(n.dataset.o, { type: ptype, ver: pver }));
}
let pPage = 0;
async function searchPacks(pg) {
  if (!pver) return; pPage = typeof pg === 'number' ? pg : 0;
  $('#pmres').innerHTML = '<p class="muted">Suche …</p>';
  try {
    const qq = catFromQuery($('#pmq').value.trim(), PACK_CATS[ptype] || []); const r = await window.cloudy.packSearch({ q: qq.q, version: pver, type: ptype, cat: pSearchCat || qq.cat, offset: pPage * 20 });
    $('#pmres').innerHTML = r.map(m => `<div class="glass srv" data-p="${esc(m.id)}"><img class="mi" src="${esc(m.icon || '')}" alt=""><div class="tx"><b>${esc(m.title)}</b> <small style="display:inline">von ${esc(m.author)} · ${fmt(m.downloads)} Downloads</small><small class="d">${esc(m.desc)}</small></div><button class="btn" data-i="${esc(m.id)}">Installieren</button></div>`).join('') || '<p class="muted">Nichts für diese Version gefunden.</p>';
    $$('#pmres > .srv').forEach((el, i) => { const c = r[i] && r[i].cats; if (c && c.length && el.querySelector('.tx')) el.querySelector('.tx').insertAdjacentHTML('beforeend', '<small class="cats">' + c.map(x => esc(catName(x))).join(' · ') + '</small>'); });
    $$('#pmres [data-i]').forEach(b => b.onclick = async () => { b.disabled = true; b.textContent = 'Lädt …'; const ok = await window.cloudy.packInstall(b.dataset.i, pver, ptype); b.textContent = ok ? 'Installiert ✓' : 'Nicht verfügbar'; if (ok) refreshPacks(); });
    $$('#pmres [data-p]').forEach(r => r.onclick = e => { if (!e.target.closest('button')) openMod(r.dataset.p, { type: ptype, ver: pver }); });
    window.pager($('#pmres'), pPage, r.length >= 20, searchPacks);
  } catch { $('#pmres').innerHTML = '<p class="muted">Modrinth ist nicht erreichbar.</p>'; }
}
const PACK_CATS = { resourcepack: ['decoration', 'utility', 'vanilla-like', 'realistic', 'simplistic', 'themed', 'tweaks', 'combat', 'cursed', 'fantasy', 'gui', 'audio', 'modded'], shader: ['semi-realistic', 'realistic', 'cartoon', 'fantasy', 'vanilla-like', 'cursed', 'atmosphere', 'shadows', 'reflections', 'path-tracing', 'colored-lighting'] };
let pSearchCat = '';
function paintPCats() { $('#pmCats').innerHTML = chips([['', 'Alle Kategorien'], ...(PACK_CATS[ptype] || []).map(c => [c, catName(c)])], pSearchCat); $$('#pmCats [data-c]').forEach(b => b.onclick = () => { pSearchCat = b.dataset.c; paintPCats(); searchPacks(); }); }
$$('[data-pt]').forEach(b => b.onclick = () => { ptype = b.dataset.pt; pcat = 'all'; pSearchCat = ''; paintPCats(); $$('[data-pt]').forEach(x => x.classList.toggle('on', x === b)); $('#pmres').innerHTML = ''; loadPacks(); });
$('#pver').onchange = e => { pver = e.target.value; $('#pmres').innerHTML = ''; refreshPacks(); searchPacks(); };
$('#pq').oninput = e => { pq = e.target.value; paintPacks(pdata); };
$('#pfolder').onclick = () => pver && window.cloudy.packFolder(pver, ptype);
$('#pmsearch').onclick = () => searchPacks(0); $('#pmq').onkeydown = e => { if (e.key === 'Enter') searchPacks(0); };
$('#pmq').onkeydown = e => { if (e.key === 'Enter') searchPacks(); };

// ---------- Screenshot-Manager ----------
let sver = '';
async function loadShots() {
  const lib = await window.cloudy.libList();
  const ids = [...new Set([version, ...lib.map(x => x.id)].filter(Boolean))];
  if (!sver || !ids.includes(sver)) sver = version || ids[0] || '';
  $('#sver').innerHTML = ids.map(i => `<option ${i === sver ? 'selected' : ''}>${esc(i)}</option>`).join('');
  if (!sver) { $('#sgrid').innerHTML = '<p class="muted">Wähle zuerst eine Version.</p>'; return; }
  const l = await window.cloudy.shotList(sver);
  $('#sgrid').innerHTML = l.map(x => `<div class="glass tile" data-sf="${esc(x.file)}" style="padding:10px">${x.thumb ? `<img src="${x.thumb}" alt="" style="width:100%;border-radius:14px;display:block">` : ''}<div style="display:flex;align-items:center;gap:8px;margin-top:8px"><small class="muted" style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(x.file)}</small><button class="chip" data-sd="${esc(x.file)}" title="In den Papierkorb">Löschen</button></div></div>`).join('') || '<p class="muted" style="margin-top:14px">Noch keine Screenshots. Im Spiel mit F2 aufnehmen.</p>';
  $$('#sgrid [data-sf]').forEach(t => t.onclick = e => { if (!e.target.closest('[data-sd]')) window.cloudy.shotOpen(sver, t.dataset.sf); });
  $$('#sgrid [data-sd]').forEach(b => b.onclick = async () => { await window.cloudy.shotDelete(sver, b.dataset.sd); loadShots(); });
}
$('#sver').onchange = e => { sver = e.target.value; loadShots(); };
$('#sfolder').onclick = () => sver && window.cloudy.shotFolder(sver);

// ---------- Performance-Presets ----------
const PRE = {
  lowend: { ram: 2, jvm: '-XX:+UseG1GC -XX:MaxGCPauseMillis=100' },
  performance: { ram: 4, jvm: '-XX:+UseG1GC -XX:MaxGCPauseMillis=50 -XX:+ParallelRefProcEnabled' },
  balanced: { ram: 4, jvm: '' },
  quality: { ram: 8, jvm: '-XX:+UseG1GC -XX:MaxGCPauseMillis=50' }
};
$('#preset').value = st.get('preset', '');
$('#preset').onchange = e => {
  const k = e.target.value; st.set('preset', k);
  const p = PRE[k]; if (!p) return;
  st.set('ram', p.ram); $('#ram').value = p.ram; $('#ramv').textContent = p.ram + ' GB';
  st.set('jvm', p.jvm); $('#jvm').value = p.jvm;
  st.set('perf', true); $('#perf').checked = true;
};

// ---------- Konfiguration exportieren / importieren ----------
$('#cfgExp').onclick = async () => {
  const ls = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); ls[k] = localStorage.getItem(k); }
  const r = await window.cloudy.cfgExport(JSON.stringify({ cloudy: 1, ls }, null, 2));
  $('#status').textContent = r.ok ? 'Einstellungen exportiert ✓' : (r.error || '');
};
$('#cfgImp').onclick = async () => {
  const r = await window.cloudy.cfgImport();
  if (!r.ok) { if (!r.cancel) $('#status').textContent = r.error; return; }
  for (const [k, v] of Object.entries(r.data.ls)) if (typeof v === 'string' && v.length < 200000) localStorage.setItem(k, v);
  location.reload();
};

// ---------- Systemanzeige (Startseite) ----------
const GB = n => (n / 1073741824).toFixed(1);
function sysRow(label, pct, text) { return `<div><div style="display:flex;justify-content:space-between;font-size:13px;font-weight:600;color:var(--ink2)"><span>${label}</span><span>${text}</span></div><div class="bar"><i style="width:${Math.min(100, pct)}%"></i></div></div>`; }
async function pollSys() {
  if (document.hidden || !$('#p-home').classList.contains('on')) return;
  try {
    const s = await window.cloudy.sysStats();
    let h = sysRow('CPU', s.cpu, s.cpu + ' %') + sysRow('Arbeitsspeicher', s.ramUsed / s.ramTotal * 100, `${GB(s.ramUsed)} / ${GB(s.ramTotal)} GB`);
    if (s.gpu) h += sysRow('GPU (' + esc(s.gpu.name) + ')', s.gpu.util, `${s.gpu.util} % · ${(s.gpu.memUsed / 1024).toFixed(1)} / ${(s.gpu.memTotal / 1024).toFixed(1)} GB`);
    if (s.mc) h += sysRow('Minecraft', s.mc / s.ramTotal * 100, GB(s.mc) + ' GB RAM');
    $('#sysRows').innerHTML = h;
  } catch {}
}
pollSys(); setInterval(pollSys, 2500);

// ---------- Glas einstellen ----------
function applyGlass() {
  const op = st.get('glassOp', null), bl = st.get('glassBlur', null), r = document.documentElement.style;
  if (op === null) r.removeProperty('--gm'); else r.setProperty('--gm', op / 100);
  if (bl === null) r.removeProperty('--glass-blur'); else r.setProperty('--glass-blur', bl + 'px');
  const gm = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--gm')) || .76;
  $('#glassOp').value = Math.round(gm * 100); $('#glassBlur').value = bl === null ? 30 : bl;
}
$('#glassOp').oninput = e => { st.set('glassOp', +e.target.value); applyGlass(); };
$('#glassBlur').oninput = e => { st.set('glassBlur', +e.target.value); applyGlass(); };
$('#glassReset').onclick = () => { st.set('glassOp', null); st.set('glassBlur', null); applyGlass(); };
$$('.th').forEach(b => b.addEventListener('click', () => setTimeout(applyGlass, 50)));
$('#themeBtn').addEventListener('click', () => setTimeout(applyGlass, 50));
applyGlass();

// ---------- Eigenes Theme: Hintergrundbild + Akzentfarbe ----------
const rootEl = document.documentElement;
function applyBg(data) {
  rootEl.classList.toggle('has-bg', !!data);
  if (data) rootEl.style.setProperty('--bg-img', `url("${data}")`); else rootEl.style.removeProperty('--bg-img');
}
function applyBgLook() {
  rootEl.style.setProperty('--bg-dim', st.get('bgDim', 35) / 100);
  rootEl.style.setProperty('--bg-blur', st.get('bgBlur', 0) + 'px');
}
function applyAccent() {
  const c = st.get('accent', '');
  for (const k of ['--accent', '--accent2', '--accent3']) rootEl.style.removeProperty(k);
  if (!c) return;
  rootEl.style.setProperty('--accent', c);
  rootEl.style.setProperty('--accent2', `color-mix(in srgb, ${c} 55%, white)`);
  rootEl.style.setProperty('--accent3', `color-mix(in srgb, ${c} 70%, #6d5cff)`);
}
$('#bgDim').value = st.get('bgDim', 35); $('#bgBlur').value = st.get('bgBlur', 0);
$('#bgDim').oninput = e => { st.set('bgDim', +e.target.value); applyBgLook(); };
$('#bgBlur').oninput = e => { st.set('bgBlur', +e.target.value); applyBgLook(); };
$('#bgPick').onclick = async () => { const r = await window.cloudy.bgPick(); if (r.ok) { applyBg(r.data); $('#bgMsg').textContent = ''; } else if (!r.cancel) $('#bgMsg').textContent = r.error; };
$('#bgClear').onclick = async () => { await window.cloudy.bgClear(); applyBg(null); };
$('#accCol').value = st.get('accent', '') || '#4aa3ff';
$('#accCol').oninput = e => { st.set('accent', e.target.value); applyAccent(); };
$('#accReset').onclick = () => { st.set('accent', ''); applyAccent(); $('#accCol').value = '#4aa3ff'; };
applyBgLook(); applyAccent();
window.cloudy.bgGet().then(applyBg);

let autoRetry = true; // pro Klick auf „Spielen“ gibt es einen automatischen zweiten Versuch (sicher, ohne Mods)
$('#play').addEventListener('click', () => autoRetry = true); $('#heroPlay').addEventListener('click', () => autoRetry = true);
// ---------- Absturz-Hilfe (Windows-Code 3221225477 = 0xC0000005 = Absturz im Grafiktreiber/nativer Code) ----------
window.cloudy.on('closed', ({ code, hs, safe }) => {
  if (Date.now() - (window.__cancelAt || 0) < 10000) return; // vom Nutzer abgebrochen: kein Absturz-Hinweis, kein Neustart-Versuch
  const el = $('#crashHint'); if (!el) return;
  const native = code === 3221225477 || code === -1073741819;
  if (native && autoRetry && !safe) { // Absturz beim Start: einmal automatisch ohne Mods neu starten
    autoRetry = false; $('#modal').style.display = 'none'; $('#status').textContent = 'Absturz beim Start – Cloudy versucht es automatisch sicher (ohne Mods) noch einmal …';
    setTimeout(() => play(undefined, { safe: 1 }), 1500); return;
  }
  if (!native && !hs) { el.style.display = 'none'; return; }
  const frame = hs && hs.frame ? `<br><small>Problemstelle: <code>${esc(hs.frame)}</code></small>` : '';
  const gpu = hs && /nvoglv|nvd3|nvwgf|atio|amdxx|ig\d+icd|ig9icd|igd/i.test(hs.frame || '');
  el.style.display = 'block';
  el.innerHTML = (gpu ? 'Der <b>Grafiktreiber</b> ist abgestürzt. Installiere den neuesten Treiber (bei NVIDIA „Clean Installation“) und schließe Overlays wie Discord, GeForce Experience oder MSI Afterburner. '
    : 'Minecraft ist im nativen Code abgestürzt (Code ' + code + '), meist Grafiktreiber, Overlay oder Mod. ') + frame +
    '<div class="tools" style="margin:10px 0 0"><button class="chip" id="crSafe">Sicherer Modus (Einstellungen zurücksetzen)</button><button class="chip" id="crStable">Mit Minecraft 1.21.4 spielen</button><button class="chip" id="noIF">Mods ausschalten &amp; neu starten</button></div>';
  $('#crSafe').onclick = () => { $('#modal').style.display = 'none'; play(undefined, { safe: 2 }); };
  $('#crStable').onclick = () => { version = '1.21.4'; st.set('version', version); paintVersion(); $('#modal').style.display = 'none'; play(undefined, {}); };
  $('#noIF').onclick = () => { $('#modal').style.display = 'none'; play(undefined, { safe: 1 }); };
});

// ---------- Lokales Update (Update-Ordner) ----------
$('#luOpen').onclick = () => window.cloudy.localUpdateFolder();
$('#luPick').onclick = async () => { const r = await window.cloudy.updatePickFile(); if (r.none && !r.msg) return; $('#luMsg').textContent = r.ok ? `Update ${r.version} installiert – Cloudy startet neu …` : r.msg; };
$('#updUrl').value = st.get('updUrl', ''); $('#updUrl').onchange = () => st.set('updUrl', $('#updUrl').value.trim());
$('#luUrl').onclick = async () => { st.set('updUrl', $('#updUrl').value.trim()); $('#luMsg').textContent = 'Lade …'; const r = await window.cloudy.updateFromUrl($('#updUrl').value); $('#luMsg').textContent = r.ok ? `Update ${r.version} installiert – Cloudy startet neu …` : r.msg; };
$('#luRun').onclick = async () => { const r = await window.cloudy.localUpdateRun(); $('#luMsg').textContent = r.ok ? `Update ${r.version} installiert – Cloudy startet neu …` : r.msg; };

// ---------- Cloudy-Konto: Anmelden / Registrieren / Admin (lokal) ----------
let lgMode = 'in';
const L = s => (window.t ? window.t(s) : s);
function lgSet(m, hint) {
  lgMode = m; const chg = m === 'chg';
  $$('[data-lt]').forEach(b => { b.classList.toggle('on', b.dataset.lt === m); b.parentElement.style.display = chg ? 'none' : ''; });
  $('#lgUserRow').style.display = chg ? 'none' : ''; $('#lgRemRow').style.display = chg ? 'none' : '';
  $('#lgPass2Row').style.display = m === 'in' ? 'none' : 'grid';
  $('#lgGo').textContent = m === 'up' ? 'Konto erstellen' : chg ? 'Passwort speichern' : 'Anmelden';
  $('#lgPass').autocomplete = m === 'in' ? 'current-password' : 'new-password'; $('#lgMsg').textContent = '';
  const h = $('#lgHint'); h.style.display = hint ? '' : 'none'; h.textContent = hint || '';
  if (window.setLang) window.setLang(document.documentElement.lang || 'de');
}
$$('[data-lt]').forEach(b => b.onclick = () => lgSet(b.dataset.lt, lgFresh && b.dataset.lt === 'in' ? FRESH_HINT : ''));
const FRESH_HINT = 'Tester-Konto: Melde dich mit Tester / 12345 an. Du musst das Passwort danach sofort ändern.';
let lgFresh = false;
function askText(q) { // prompt() gibt es in Electron nicht – kleines eigenes Eingabefeld
  return new Promise(res => { const d = document.createElement('div'); d.style.cssText = 'position:fixed;inset:0;z-index:99999;display:grid;place-items:center;background:rgba(0,0,0,.35)';
    d.innerHTML = `<div class="glass set" style="padding:18px;min-width:300px"><b>${esc(q)}</b><input class="field" style="margin:10px 0;width:100%" autocomplete="off"><div class="tools" style="margin:0"><button class="btn" data-o>OK</button><button class="btn ghost" data-c>Abbrechen</button></div></div>`;
    document.body.appendChild(d); const i = d.querySelector('input'); i.focus(); const done = v => { d.remove(); res(v); };
    d.querySelector('[data-o]').onclick = () => done(i.value); d.querySelector('[data-c]').onclick = () => done(null); i.onkeydown = e => { if (e.key === 'Enter') done(i.value); if (e.key === 'Escape') done(null); }; });
}
async function paintAdmin(on) {
  $('#admBox').style.display = on ? '' : 'none'; if (!on) return;
  const us = await window.cloudy.authListFull();
  $('#admList').innerHTML = us.length ? us.map(u => `<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0;${u.banned ? 'opacity:.7' : ''}"><b style="flex:1;min-width:120px">${esc(u.name)} <small class="muted">${u.coins} CC · ${u.owned} Items${u.banned ? ' · GESPERRT' + (u.reason ? ': ' + esc(u.reason) : '') : ''}</small></b><button class="btn ghost" data-ab="${esc(u.name)}" data-bn="${u.banned ? 0 : 1}">${u.banned ? 'Entsperren' : 'Sperren'}</button><button class="btn ghost" data-ac="${esc(u.name)}">CC setzen</button><button class="btn ghost" data-ag="${esc(u.name)}">+500 CC</button><button class="btn ghost" data-ar="${esc(u.name)}">Passwort → 12345</button><button class="btn ghost" data-ad="${esc(u.name)}">Konto löschen</button></div>`).join('') : 'Keine weiteren Konten.';
  $$('#admList [data-ab]').forEach(b => b.onclick = async () => { const ban = b.dataset.bn === '1'; let reason = ''; if (ban) reason = (await askText('Grund für die Sperre (optional)')) || ''; await window.cloudy.authAdminBan({ name: b.dataset.ab, banned: ban, reason }); paintAdmin(true); });
  $$('#admList [data-ac]').forEach(b => b.onclick = async () => { const v = await askText('Neuer CC-Stand für ' + b.dataset.ac); if (v == null || v === '') return; await window.cloudy.authAdminCoins({ name: b.dataset.ac, amount: v }); paintAdmin(true); });
  $$('#admList [data-ar]').forEach(b => b.onclick = async () => { await window.cloudy.authAdminReset(b.dataset.ar); paintAdmin(true); });
  $$('#admList [data-ag]').forEach(b => b.onclick = async () => { await window.cloudy.authAdminGrant({ name: b.dataset.ag, amount: 500 }); b.textContent = '✓ +500 CC'; });
  $$('#admList [data-ad]').forEach(b => b.onclick = async () => { if (confirm(b.dataset.ad + ' – ' + L('Löschen') + '?')) { await window.cloudy.authAdminDelete(b.dataset.ad); paintAdmin(true); } });
  if (window.setLang) window.setLang(document.documentElement.lang || 'de');
}
function lgDone(name, first, admin) {
  $('#login').classList.add('off'); $('#lgPass').value = $('#lgPass2').value = '';
  if (first) { st.set('name', name); $('#name').value = name; paintUser(); }
  $('#delBtn').style.display = admin ? 'none' : ''; $('#delRow').style.display = 'none';
  paintAdmin(!!admin); if (window.onLoggedIn) window.onLoggedIn();
  if (!st.get('onboarded', false)) showOnb();
}
$('#lgForm').onsubmit = async e => {
  e.preventDefault();
  const user = $('#lgUser').value.trim(), pass = $('#lgPass').value, msg = $('#lgMsg');
  if (lgMode !== 'chg' && (!user || !pass)) { msg.textContent = L('Bitte Benutzername und Passwort eingeben.'); return; }
  if (lgMode !== 'in' && pass !== $('#lgPass2').value) { msg.textContent = L('Die Passwörter sind nicht gleich.'); return; }
  $('#lgGo').disabled = true; msg.textContent = '';
  const c = window.cloudy, r = lgMode === 'chg' ? await c.authChangePass({ pass }) : await c[lgMode === 'up' ? 'authRegister' : 'authLogin']({ user, pass, remember: $('#lgRem').checked });
  $('#lgGo').disabled = false;
  if (!r.ok) { msg.textContent = L(r.error); return; }
  if (r.mustChange) { $('#lgPass').value = ''; lgSet('chg', 'Du nutzt ein vorläufiges Passwort. Lege jetzt ein neues fest.'); return; }
  lgFresh = false; lgDone(r.user, !!r.first, r.admin);
};
$('#lgForgot').onclick = async e => {
  e.preventDefault();
  if (confirm(L('Das Tester-Konto auf Tester / 12345 zurücksetzen? Andere Konten (auch Admin) bleiben erhalten. Das Passwort muss danach sofort neu gesetzt werden.'))) { await window.cloudy.authReset(); lgFresh = true; lgSet('in', FRESH_HINT); }
};
$('#authOut').onclick = async () => { await window.cloudy.authLogout(); const s = await window.cloudy.authState(); lgFresh = s.fresh; $('#login').classList.remove('off'); lgSet('in', s.fresh ? FRESH_HINT : ''); $('#lgPass').value = ''; paintAdmin(false); };
window.cloudy.authState().then(s => { lgFresh = s.fresh; if (s.user) lgDone(s.user, false, s.admin); else lgSet('in', s.fresh ? FRESH_HINT : ''); });

// ---------- Notfall: Neu laden / Update erzwingen (auch per F5 bzw. Strg+Umschalt+U) ----------
$('#reloadBtn').onclick = () => window.cloudy.appReload();
$('#forceUpd').onclick = async () => { const r = await window.cloudy.forceUpdate(); $('#luMsg').textContent = r && r.ok ? `Update ${r.version} installiert – Cloudy startet neu …` : (window.t ? window.t((r && r.msg) || 'Kein Update im Update-Ordner gefunden.') : ((r && r.msg) || '')); };

// ---------- Reiter: Versionen | Bibliothek, Mods | Ressourcen, Einstellungen | Screenshots ----------
(function () {
  const G = [[['versions', 'Versionen'], ['lib', 'Bibliothek']], [['mods', 'Mods'], ['packs', 'Ressourcen']], [['settings', 'Einstellungen'], ['shots', 'Screenshots']]];
  G.forEach(g => g.forEach(([id]) => {
    const pg = $('#p-' + id); if (!pg) return;
    const bar = document.createElement('div'); bar.className = 'tools subtabs';
    bar.innerHTML = g.map(([k, n]) => `<button class="chip" data-sg="${k}">${n}</button>`).join('');
    pg.insertBefore(bar, pg.firstChild);
    bar.querySelectorAll('[data-sg]').forEach(b => b.onclick = () => go(b.dataset.sg));
  }));
  window.paintSub = p => $$('.subtabs [data-sg]').forEach(b => b.classList.toggle('on', b.dataset.sg === p));
  window.paintSub($('.page.on') ? $('.page.on').id.slice(2) : 'home');
})();

// ---------- Konto löschen ----------
$('#delBtn').onclick = () => { const r = $('#delRow'); r.style.display = r.style.display === 'none' ? 'flex' : 'none'; $('#delMsg').textContent = ''; $('#delPass').value = ''; };
$('#delGo').onclick = async () => {
  const r = await window.cloudy.authDelete({ pass: $('#delPass').value });
  if (!r.ok) { $('#delMsg').textContent = window.t ? window.t(r.error) : r.error; return; }
  $('#delRow').style.display = 'none'; $('#authOut').onclick();
};
window.showOnb = showOnb;

// ---------- Konto-Server (Einstellungen) ----------
(function () {
  const inp = document.getElementById('srvUrl'), btn = document.getElementById('srvSave'), msg = document.getElementById('srvMsg'); if (!inp || !btn || !window.cloudy.srvGet) return;
  window.cloudy.srvGet().then(u => { inp.value = u || ''; msg.textContent = u ? 'Verbunden mit diesem Server.' : 'Kein Server: Konten nur auf diesem PC.'; }).catch(() => {});
  btn.onclick = async () => {
    btn.disabled = true; msg.textContent = 'Prüfe …'; const r = await window.cloudy.srvSet(inp.value); btn.disabled = false;
    if (!r.ok) { msg.textContent = r.error; return; }
    msg.textContent = r.off ? 'Server entfernt. Bitte neu anmelden …' : 'Server gespeichert. Bitte neu anmelden …';
    setTimeout(() => location.reload(), 900);
  };
})();
