Hier liegt cloudy-client.jar (die Client-Mod). Sie wird gebaut, nicht mitgeliefert:
 - GitHub: Actions > "Cloudy bauen" erledigt das automatisch, oder
 - lokal: "Cloudy Client bauen.command (macOS) / Cloudy Client bauen.bat (Windows)" doppelklicken.
