// Cloudy-Updater: prüft GitHub-Releases, lädt mit Fortschritt herunter, installiert und startet Cloudy neu.
// Nutzerdaten (Einstellungen, Mods, Profile, Welten) liegen in AppData/Application Support und werden nie angefasst.
const fs = require('fs'), path = require('path');
const { spawn } = require('child_process');

exports.init = function init({ app, ipcMain, shell, send, defaultRepo, userAgent, gameRunning }) {
  const IS_MAC = process.platform === 'darwin', IS_WIN = process.platform === 'win32';
  const PORTABLE = IS_WIN && process.env.PORTABLE_EXECUTABLE_FILE;
  const H = { 'User-Agent': userAgent || 'Cloudy-Updater' };
  let found = null, busy = false;

  const nums = v => String(v).replace(/^v/i, '').split('.').map(n => parseInt(n, 10) || 0);
  const newer = (a, b) => { const x = nums(a), y = nums(b); for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };

  // Pflicht-Update: Eine neuere Version, die schon seit mehr als 24 Stunden bekannt ist, muss installiert werden (kein Aufschieben, kein Zurückgehen).
  const seenFile = path.join(app.getPath('userData'), 'update-seen.json');
  function seen(ver) {
    let j = {}; try { j = JSON.parse(fs.readFileSync(seenFile, 'utf8')); } catch {}
    if (j.ver !== ver) { j = { ver, t: Date.now() }; try { fs.writeFileSync(seenFile, JSON.stringify(j)); } catch {} }
    return Date.now() - j.t > 24 * 3600 * 1000;
  }
  exports.seen = seen;
  function pick(assets) {
    const a = assets || [];
    if (IS_WIN) return a.find(x => /\.exe$/i.test(x.name) && (PORTABLE ? /portable/i : /setup/i).test(x.name)) || a.find(x => /\.exe$/i.test(x.name) && !/portable/i.test(x.name));
    if (IS_MAC) return a.find(x => /\.dmg$/i.test(x.name) && x.name.toLowerCase().includes(process.arch === 'arm64' ? 'arm64' : 'x64'));
    return null;
  }

  ipcMain.handle('checkUpdate', async (_e, repo) => {
    repo = defaultRepo || repo;
    if (!/^[\w.-]+\/[\w.-]+$/.test(repo || '')) return { ok: false, error: 'Trage deine GitHub-Quelle ein (z. B. name/cloudy) oder setze sie in config/app.json.' };
    try {
      const res = await fetch(`https://api.github.com/repos/${repo}/releases/latest`, { headers: H });
      if (!res.ok) throw new Error(res.status);
      const r = await res.json(), latest = String(r.tag_name).replace(/^v/i, ''), cur = app.getVersion();
      const asset = pick(r.assets);
      found = { asset, url: r.html_url };
      const nw = newer(latest, cur);
      return { ok: true, current: cur, latest, newer: nw, mandatory: nw && seen(latest), url: r.html_url, canInstall: !!asset && app.isPackaged,
        size: asset ? asset.size : 0, notes: String(r.body || '').slice(0, 600) };
    } catch { return { ok: false, error: 'Keine Release gefunden oder keine Verbindung.' }; }
  });

  async function download(asset) {
    const dir = path.join(app.getPath('temp'), 'cloudy-update');
    fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
    const dest = path.join(dir, asset.name);
    const res = await fetch(asset.browser_download_url, { headers: H });
    if (!res.ok || !res.body) throw new Error('Download fehlgeschlagen (' + res.status + ')');
    const total = +res.headers.get('content-length') || asset.size, ws = fs.createWriteStream(dest);
    let got = 0, last = 0;
    for await (const chunk of res.body) {
      if (!ws.write(chunk)) await new Promise(r => ws.once('drain', r));
      got += chunk.length;
      const now = Date.now();
      if (now - last > 120) { last = now; send('update-progress', { phase: 'download', pct: total ? Math.min(100, got / total * 100) : 0, got, total }); }
    }
    await new Promise((ok, bad) => { ws.on('error', bad); ws.end(ok); });
    if (asset.size && got !== asset.size) throw new Error('Datei unvollständig – bitte erneut versuchen.');
    send('update-progress', { phase: 'download', pct: 100, got, total });
    return dest;
  }

  function install(file) {
    const detached = { detached: true, stdio: 'ignore', windowsHide: true };
    if (IS_WIN && !PORTABLE) {
      // Installer läuft still, behält den Installationsordner und startet Cloudy danach neu
      spawn(file, ['/S', '--updated', '--force-run'], detached).unref();
    } else if (IS_WIN) {
      const old = process.env.PORTABLE_EXECUTABLE_FILE, bat = path.join(path.dirname(file), 'apply.bat');
      fs.writeFileSync(bat, ['@echo off', 'set n=0', 'ping -n 3 127.0.0.1 >nul', ':retry', `move /y "${file}" "${old}" >nul 2>&1 && goto done`,
        'set /a n+=1', 'if %n% gtr 40 exit /b 1', 'ping -n 2 127.0.0.1 >nul', 'goto retry', ':done', `start "" "${old}"`, ''].join('\r\n'));
      spawn('cmd.exe', ['/c', bat], detached).unref();
    } else if (IS_MAC) {
      const target = path.resolve(process.execPath, '..', '..', '..');
      if (!target.endsWith('.app')) return shell.openPath(file);
      const sh = path.join(path.dirname(file), 'apply.sh');
      fs.writeFileSync(sh, `#!/bin/sh
DMG="$1"; T="$2"; M=$(mktemp -d /tmp/cloudy-mnt.XXXXXX)
sleep 2
hdiutil attach -nobrowse -quiet -noverify -mountpoint "$M" "$DMG" || { open "$DMG"; exit 1; }
S=$(ls -d "$M"/*.app | head -n 1)
rm -rf "$T.new"
if cp -R "$S" "$T.new" && rm -rf "$T" && mv "$T.new" "$T"; then
  xattr -cr "$T"; codesign --force --deep --sign - "$T" 2>/dev/null
  hdiutil detach -quiet "$M"; open "$T"
else hdiutil detach -quiet "$M"; open "$DMG"; fi
`, { mode: 0o755 });
      spawn('/bin/sh', [sh, file, target], detached).unref();
    }
    send('update-progress', { phase: 'install', pct: 100 });
    setTimeout(() => app.quit(), 800);
  }

  ipcMain.handle('updateInstall', async () => {
    if (busy) return { ok: false, error: 'Update läuft bereits.' };
    if (gameRunning && gameRunning()) return { ok: false, error: 'Bitte zuerst Minecraft beenden – dann kann Cloudy aktualisieren.' };
    if (!found || !found.asset || !app.isPackaged) { if (found) shell.openExternal(found.url); return { ok: false, opened: true, error: 'Automatisches Installieren geht hier nicht – die Download-Seite wurde geöffnet.' }; }
    busy = true;
    try { install(await download(found.asset)); return { ok: true }; }
    catch (e) { busy = false; return { ok: false, error: String((e && e.message) || e) }; }
  });
};
